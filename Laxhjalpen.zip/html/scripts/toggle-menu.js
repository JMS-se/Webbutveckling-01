(function () {
    "use strict";
    // Skapa knappen som visar/döljer menyn
    // Lagra åtkomst till knappen i en variabel
    // Lagra åtkonst till menyn i en variabel
    // När någon klickar på knappen
        // Om menyn redan visas
            // Ska den döljas
            // Och ändra knappens text
            // Annars ska den visas
            // Och knappens text ändras
}());
